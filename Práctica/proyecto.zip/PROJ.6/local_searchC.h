#include "State.h"

class localSearch {
    private:
    public:
    localSearch();
    State hillClimbing(State current, int &iteration); 
};
