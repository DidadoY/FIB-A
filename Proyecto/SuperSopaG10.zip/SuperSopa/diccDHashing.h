#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include "basicTypes.cc"
using namespace std;

set<string> diccDHashingFind(VVC& board, const vector<string>& words);
