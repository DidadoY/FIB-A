#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <set>
#include "basicTypes.cc"
using namespace std;


set<string> diccSortedVectorFind(VVC& board, vector<string> words);
