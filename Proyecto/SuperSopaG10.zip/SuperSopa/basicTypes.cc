#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

typedef vector<pair<char,bool>> VC;
typedef vector<VC>VVC;
typedef pair<int,int> direction;

#define Up direction (-1,0)
#define Down direction (1,0)
#define Left direction (0,-1)
#define Right direction (0,1)
#define UpRight direction (-1,1)
#define UpLeft direction (-1,-1)
#define DownRight direction (1,1)
#define DownLeft direction (1,-1)