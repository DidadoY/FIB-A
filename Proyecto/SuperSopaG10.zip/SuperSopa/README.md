# SuperSopa

david.galvez.alcantara@estudiantat.upc.edu\
pol.garrido.melis@estudiantat.upc.edu\
marc.nebot.moyano@estudiantat.upc.edu\
lidia.rossell@estudiantat.upc.edu


# Execution

make \
./main.x < ./Testing/(Select a file from the folder)
