#include "diccDHashing.h"
#include "basicTypes.cc"

const static int P = 29;
const static int P2 = 31;
const static int margin =1; //To avoid colisions. It can be 0, but with 1 or 2 we may get a better performance
int m;


static bool insideBoard(int i, int j, int n){
    return(i>=0 and j>=0 and i<n and j<n);
}


int hashCompute(string word, int p){
    unsigned long long hash = 0;
    unsigned long long power = 1;
    for(int i=0;i<word.size();++i){
        hash = (hash+(word[i]*power)%m)%m;
        power = power*p;
    }
    return int(hash%m);
}

void insertCompleteWord(string word,vector<pair<string,bool>>& hashVector, bool endWord){
    unsigned long long hash1 = hashCompute(word, P);
    unsigned long long hash2 = hashCompute(word, P2);

    int xi = int(hash1%m);
    if(hash2%2==0)
        ++hash2;

    while(hashVector[xi].first!="" and hashVector[xi].first!=word){
        xi =(xi+hash2)%m;
    }
    hashVector[xi].first=word;
    hashVector[xi].second = hashVector[xi].second or endWord ;
     
}

pair<bool,bool> search(const vector<pair<string,bool>>& hashVector,string word){
    int x0 = hashCompute(word,P);
    int x1 = hashCompute(word,P2);
    if(x1%2==0)
        ++x1;
    
    while(hashVector[x0].first!="" and hashVector[x0].first!=word){
        x0 =(x0+x1)%m;
    }
    return make_pair(hashVector[x0].first==word,hashVector[x0].second);
}

static vector<pair<string,bool>> preprocess(const vector<string>& words){
    int count=0;
    int max = 0;
    for(int i=0;i<words.size();++i){
        count+=words[i].size();
        if (max < words[i].size()) max = words[i].size();
    }
    
    int nearestPowerTwoWithMargin = floor(log2(count))+1+margin;
    m = pow(2,nearestPowerTwoWithMargin);
    vector<pair<string,bool>>hashVector = vector<pair<string,bool>>(m,make_pair("",false));
    
    for (int i = 0; i <= max; i++) {
        for (int j = 0; j < words.size(); j++) {
            if (i < words[j].size()) {
                insertCompleteWord(words[j].substr(0,i+1), hashVector, words[j].size()-1 == i);
            }
        }
    }
    
    return hashVector;
}


bool makesSense(VVC& board,int i, int j, string currentWord,const vector<pair<string,bool>>& dictionary,int deepness){
    if(board[i][j].second)return false;
    pair<bool,bool> k = search(dictionary,currentWord);
    return k.first;
}


void diccDHashingFind(VVC& board,const vector<pair<string,bool>>& dictionary,set<string>& foundWords,int i, int j, string currentWord, int deepness){
    board[i][j].second=true;
    if(search(dictionary,currentWord).second){
        foundWords.insert(currentWord);
    }
    vector<direction> allDirections={Down,Up,Left,Right,UpRight,UpLeft,DownRight,DownLeft};
    for(auto dir: allDirections){
        if(insideBoard(i+dir.first,j+dir.second,board.size())){
            string partialword = currentWord;
            partialword.push_back(board[i+dir.first][j+dir.second].first);
            if(makesSense(board,i+dir.first,j+dir.second,partialword,dictionary,deepness+1)){
                diccDHashingFind(board,dictionary,foundWords,i+dir.first,j+dir.second,partialword,deepness+1);
            }
        }
    }
    board[i][j].second=false;
}



set<string> diccDHashingFind(VVC& board, const vector<string>& words){
    vector<pair<string,bool>> dictionary= preprocess(words);
    
    set<string> foundWords;
    
    for(int i=0;i<board.size();++i){
        for(int j=0;j<board.size();++j){
            string initial ="";
            initial.push_back(board[i][j].first);
            if(makesSense(board,i,j,initial,dictionary,1)){
                diccDHashingFind(board,dictionary,foundWords,i,j,initial,1);
            }
        }
    }
    return foundWords;
}
