#include "diccTrie.h"
#include "basicTypes.cc"

struct TrieNode *getNode()
{
    struct TrieNode *node =  new TrieNode;
  
    node->isEndOfWord = false;
  
    for (int i = 0; i < ALPHABET_SIZE; i++)
        node->successors[i] = NULL;
  
    return node;
}

static bool insideBoard(int i, int j, int n){
    return(i>=0 and j>=0 and i<n and j<n);
}


void insert(struct TrieNode *root, string key)
{
    struct TrieNode *auxNode = root;
  
    for (int i = 0; i < key.length(); i++)
    {
        int index = key[i] - 'a';
        if (!auxNode->successors[index])
            auxNode->successors[index] = getNode();
  
        auxNode = auxNode->successors[index];
    }
  
    auxNode->isEndOfWord = true;
}

struct TrieNode* preprocess(const vector<string>& words){
    struct TrieNode* empty = getNode();
    
    for(int i = 0;i<words.size();++i){
        insert(empty,words[i]);
    }
    
    return empty;
}

pair<bool,int> search(struct TrieNode *root, string key)
{
    struct TrieNode *auxNode = root;
    
    int count =0;

    for (int i = 0; i < key.length(); i++)
    {
        int index = key[i] - 'a';
        if (!auxNode->successors[index])
            return make_pair(false,count);
        
        ++count;
        auxNode = auxNode->successors[index];
    }
  
    return make_pair((auxNode->isEndOfWord),count);
}

bool makesSense(VVC& board,int i, int j, string currentWord,struct TrieNode* dictionary,int deepness){
    if(board[i][j].second)return false;
    pair<bool,int> k = search(dictionary,currentWord);
    return (k.second==deepness);
}


void diccTrieFind(VVC& board,struct TrieNode* dictionary,set<string>& foundWords,int i, int j, string currentWord, int deepness){
    board[i][j].second=true;
    if(search(dictionary,currentWord).first){
        foundWords.insert(currentWord);
    }
    vector<direction> allDirections={Down,Up,Left,Right,UpRight,UpLeft,DownRight,DownLeft};
    for(auto dir: allDirections){        
        if(insideBoard(i+dir.first,j+dir.second,board.size())){
            string partialword = currentWord;
            partialword.push_back(board[i+dir.first][j+dir.second].first);
            if(makesSense(board,i+dir.first,j+dir.second,partialword,dictionary,deepness+1)){
                diccTrieFind(board,dictionary,foundWords,i+dir.first,j+dir.second,partialword,deepness+1);
            }
        }
    }
    board[i][j].second=false;
}



set<string> diccTrieFind(VVC& board, const vector<string>& words){
    struct TrieNode *dictionary = preprocess(words);
    
    set<string> foundWords;
    
    for(int i=0;i<board.size();++i){
        for(int j=0;j<board.size();++j){
            string initial ="";
            initial.push_back(board[i][j].first);
            if(makesSense(board,i,j,initial,dictionary,1)){
                diccTrieFind(board,dictionary,foundWords,i,j,initial,1);
            }
        }
    }
    
    return foundWords;
}
