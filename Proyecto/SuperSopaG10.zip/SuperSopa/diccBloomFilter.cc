#include "diccBloomFilter.h"
#include "basicTypes.cc"

static bool insideBoard(int i, int j, int n){
    return(i>=0 and j>=0 and i<n and j<n);
}

int hash1(string s, int arrSize)
{
	long long int hash = 0;
	for (int i = 0; i < s.size(); i++)
	{
		hash = (hash + ((int)s[i]));
		hash = hash % arrSize;
	}
	return hash;
}

int hash2(string s, int arrSize)
{
	long long int hash = 1;
    long long int p = 1;
	for (int i = 0; i < s.size(); i++)
	{
		hash = hash + p * s[i];
		hash = hash % arrSize;
        
        p = (p*19)%arrSize;
	}
	return hash % arrSize;
}

int hash3(string s, int arrSize)
{
	long long int hash = 7;
	for (int i = 0; i < s.size(); i++)
	{
		hash = (hash * 31 + s[i]) % arrSize;
	}
	return hash % arrSize;
}

int hash4(string s, int arrSize)
{
	long long int hash = 3;
	long long int p = 7;
	for (int i = 0; i < s.size(); i++) {
		hash += hash * 7 + s[0] * p;
		hash = hash % arrSize;
        p = (p*7)%arrSize;
	}
	return hash;
}

void insert(vector<pair<bool,bool>>& filter, int size, string s)
{
    int h1,h2,h3,h4;
    string aux = "";
    for(int i=0;i<s.size();++i){
        aux.push_back(s[i]);        
        h1 = hash1(aux, size);
        h2 = hash2(aux, size);
        h3 = hash3(aux, size);
        h4 = hash4(aux, size);

        filter[h1].first = true;
        filter[h2].first = true;
        filter[h3].first = true;
        filter[h4].first = true;
        
        filter[h1].second = filter[h1].second || (i==s.size()-1);
        filter[h2].second = filter[h2].second || (i==s.size()-1);
        filter[h3].second = filter[h3].second || (i==s.size()-1);
        filter[h4].second = filter[h4].second || (i==s.size()-1);
    }
}

static vector<pair<bool,bool>> preprocess(vector<string>& words, int size){
    vector<pair<bool,bool>> filter(size, make_pair(false,false));
    for (int i = 0; i < words.size(); ++i) insert(filter, size, words[i]);
    return filter;
}

pair<bool,bool> isInside(const vector<pair<bool,bool>>& filter, int size, string s){
    int h1,h2,h3,h4;
    h1 = hash1(s, size);
    h2 = hash2(s, size);
    h3 = hash3(s, size);
    h4 = hash4(s, size);

	if (filter[h1].first && filter[h2].first && filter[h3].first && filter[h4].first)
		return make_pair(true,filter[h1].second && filter[h2].second && filter[h3].second &&filter[h4].second);
	else
		return make_pair(false,false);
}

bool makesSense(VVC& board,int i, int j, string currentWord,const vector<pair<bool,bool>>& bloom){
    if(board[i][j].second)return false;
    return isInside(bloom, bloom.size(),currentWord).first;
}

void diccBloomFilterFind(VVC& board, const vector<pair<bool,bool>>& bloom,set<string>& foundWords,int i, int j, string currentWord, int deepness){
    if (isInside(bloom, bloom.size(), currentWord).second){
        foundWords.insert(currentWord);
    }
    vector<direction> allDirections={Down,Up,Left,Right,UpRight,UpLeft,DownRight,DownLeft};
    for(auto dir: allDirections){
        if(insideBoard(i+dir.first,j+dir.second,board.size())){
            string partialword = currentWord;
            partialword.push_back(board[i+dir.first][j+dir.second].first);
            if(makesSense(board,i+dir.first,j+dir.second,partialword,bloom)){
                diccBloomFilterFind(board,bloom,foundWords,i+dir.first,j+dir.second,partialword,deepness+1);
            }
        }
    }
    board[i][j].second=false;
}

set<string> diccBloomFilterFind(VVC& board, vector<string> words){
    int bloomFilterSize = 0;
    for (int i=0;i<words.size();++i) bloomFilterSize += words[i].size();
    bloomFilterSize *= 200;
    vector<pair<bool,bool>> bloomFilter = preprocess(words, bloomFilterSize);
    set<string> foundWords;
    
    for(int i=0;i<board.size();++i){
        for(int j=0;j<board.size();++j){
            string initial ="";
            initial.push_back(board[i][j].first);
            if(makesSense(board,i,j,initial,bloomFilter)){
                diccBloomFilterFind(board,bloomFilter,foundWords,i,j,initial,0);
            }
        }
    }
    return foundWords;
}
