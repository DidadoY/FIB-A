#include <iostream>
#include <vector>
#include <string>
#include <unordered_set>
#include <algorithm>
#include "diccSortedVector.h"
#include "diccBloomFilter.h"
#include "diccTrie.h"
#include "diccDHashing.h"
#include "basicTypes.cc"

using namespace std;

bool insideBoard(int i, int j, int n){
    return(i>=0 and j>=0 and i<n and j<n);
}

pair<bool,vector<direction>> enoughRoom(VVC& board, int i, int j, int n){
    if(board[i][j].first!='0')return make_pair(false,vector<direction>());

    vector<direction> directions;
    if(n==0)return make_pair(true,vector<direction>());
    
    if(board[i][j].second==false){
        board[i][j].second=true;
        vector<direction> allDirections={Down,Up,Left,Right,UpRight,UpLeft,DownRight,DownLeft};
        random_shuffle(allDirections.begin(),allDirections.end());
        for(auto dir: allDirections){  
            if(insideBoard(i+dir.first,j+dir.second,board.size())){
                pair<bool,vector<direction>> possible=enoughRoom(board,i+dir.first,j+dir.second,n-1);
                if(possible.first){
                    possible.second.push_back(dir);
                    return make_pair(true,possible.second);
                }
            }
            
        }
    }
    return make_pair(false,vector<direction>());
}


void place(VVC& board, string word, int i, int j,vector<direction> directions){
    for(int l = directions.size()-1;l>=0;--l){
        direction dir=directions[l];
        board[i][j].first=word[l];
        i += dir.first;
        j += dir.second;
    }
}

void place(VVC& board, string word){
    int i = rand()%board.size();
    int j = rand()%board.size();
    
    pair<bool,vector<direction>> placement = enoughRoom(board,i,j,word.size());
    
    while(!placement.first){
        i = rand()%board.size();
        j = rand()%board.size();
        placement = enoughRoom(board,i,j,word.size());
        
        for(int i=0;i<board.size();++i){
            for(int j=0;j<board.size();++j)
                board[i][j].second=false;
        }
        
    }
    
    place(board,word,i,j,placement.second);
}

int main(){    
    int testing,numberWords,boardSize,plantWords,decision,seed;
    cin>>testing;
    cin>>numberWords>>plantWords;
    vector<string> dictionary(numberWords);
    for(int i=0;i<numberWords;++i)
        cin>>dictionary[i];
    
    cin>>boardSize;
    cin>>decision;
    cin>>seed;
    srand(seed);

    unordered_set<string> selectedWords;
    
    while(selectedWords.size()!=plantWords){
        int pos = rand()%dictionary.size();
        if(selectedWords.find(dictionary[pos])==selectedWords.end()){
            selectedWords.insert(dictionary[pos]);
        }
    }
    
    if(!testing){
        for(auto d:selectedWords)
            cout<<d<<endl;
    }
    
    VVC board(boardSize,VC(boardSize,make_pair('0',false)));
    
    for(auto word:selectedWords)
        place(board,word);
    
    for(int i=0;i<boardSize;++i){
        for(int j=0;j<boardSize;++j){
            if(board[i][j].first=='0')
                board[i][j].first='a'+rand()%('z'-'a'+1);//'0' (Use 0 for easier debugging);
        }
    }

    if(!testing){
        for(int i=0;i<boardSize;++i){
            for(int j=0;j<boardSize;++j){
                cout<<board[i][j].first;
            }
            cout<<endl;   
        }
    }
    
    for(int i=0;i<board.size();++i){
        for(int j=0;j<board.size();++j)
            board[i][j].second=false;
    }
    
    if(!testing){
        cout<<"Select strategy: "<<endl;
        cout<<"1: Sorted vector"<<endl;
        cout<<"2: Trie"<<endl;
        cout<<"3: Bloom filter"<<endl;
        cout<<"4: Double hashing table"<<endl;
    }
    
    set<string> found;
    
    if(decision==1){
        found = diccSortedVectorFind(board,dictionary);
    }
    else if(decision == 2){
        found = diccTrieFind(board,dictionary);
    }
    else if(decision==3){
        found = diccBloomFilterFind(board,dictionary);
    }
    else{
        found = diccDHashingFind(board,dictionary);
    }
    
    bool allFound = true;
    string aux;
    for(auto w: selectedWords){
        allFound=allFound and (found.find(w)!=found.end());
        aux = w;
        if(!allFound)break;
    }
    
    if(!testing){
        cout<<(allFound ? "All words were found. Words not selected but that appear in the dictionary may have been found as a result of the placement and searching mechanism ":aux)<<endl;
        cout<<"Found: "<<endl;
        for(auto w: found)
            cout<<w<<endl;
    }
}
