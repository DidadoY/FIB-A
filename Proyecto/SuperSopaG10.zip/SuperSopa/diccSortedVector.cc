#include "diccSortedVector.h"
#include "basicTypes.cc"

int maxLength;

static vector<string> preprocess(vector<string>& words){
    maxLength = 0;
    for(int i=0;i<words.size();++i){
        if(words[i].size()>maxLength)
            maxLength = words[i].size();
    }
    sort(words.begin(),words.end());
    return words;
}


static bool insideBoard(int i, int j, int n){
    return(i>=0 and j>=0 and i<n and j<n);
}

pair<bool,int> dicotomicSearch(const vector<string>& words,int l, int r, string word, int deepness){
    if(l>r)return make_pair(false,l);
    if(r==l){
        if(r<0) return make_pair(false,0);
        if(r>=words.size())return make_pair(false,words.size()-1);
        if(words[r]==word)return make_pair(true,r);
        if(r+1<words.size() && words[r+1][deepness]==word[deepness]) return make_pair(false,r+1);
        else return make_pair(false,r);
    }
    
    int n =(l+r)/2;
    if(words[n]==word)return make_pair(true,n);
    
    if(words[n]>word)return dicotomicSearch(words,l,n-1,word, deepness);
    else return dicotomicSearch(words,n+1,r,word, deepness);
}


bool makesSense(VVC& board,int i, int j, string currentWord,const vector<string>& words,int deepness){
    if(board[i][j].second)return false;
    int k = dicotomicSearch(words,0,words.size(),currentWord, deepness).second;
    if(words[k][deepness]!=currentWord[deepness] and k<words.size()-1)++k;
    if(words[k][deepness]!=currentWord[deepness])return false;
    return true;
}

void reset(VVC& board){
    for(int i=0;i<board.size();++i){
        for(int j = 0;j<board.size();++j){
            board[i][j].second=false;
        }
    }
}

void diccSortedVectorFind(VVC& board,const vector<string>& words,set<string>& foundWords,int i, int j, string currentWord, int deepness){
    board[i][j].second=true;
    if(dicotomicSearch(words,0,words.size(),currentWord, deepness).first){
        foundWords.insert(currentWord);
    }
    if(currentWord.size()!=maxLength){
        vector<direction> allDirections={Down,Up,Left,Right,UpRight,UpLeft,DownRight,DownLeft};
        for(auto dir: allDirections){
            if(insideBoard(i+dir.first,j+dir.second,board.size())){
                string partialword = currentWord;
                partialword.push_back(board[i+dir.first][j+dir.second].first);
                if(makesSense(board,i+dir.first,j+dir.second,partialword,words,deepness+1)){
                    diccSortedVectorFind(board,words,foundWords,i+dir.first,j+dir.second,partialword,deepness+1);
                }
            }
        }
    }
    board[i][j].second=false;
}


set<string> diccSortedVectorFind(VVC& board, vector<string> words){
    vector<string> sortedWords = preprocess(words); //It may be useful to insert the reverse words too
    
    set<string> foundWords;
    
    for(int i=0;i<board.size();++i){
        for(int j=0;j<board.size();++j){
            string initial ="";
            initial.push_back(board[i][j].first);
            if(makesSense(board,i,j,initial,words,0)){
                diccSortedVectorFind(board,words,foundWords,i,j,initial,0);
            }
            //reset(board);
        }
    }
    
    return foundWords;
}
